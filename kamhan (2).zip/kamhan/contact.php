<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="//gmpg.org/xfn/11">
		<title>Kamhan Industrial | Footwear | Manufacturing & Machinery</title>
		<meta name="robots" content="max-image-preview:large">
		<link rel="dns-prefetch" href="//fonts.googleapis.com">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
		<link rel="stylesheet" href="./css/tabs.css">
		<link rel="stylesheet" id="bootstrap-css" href="css/bootstrap.min.css" type="text/css" media="all">
		<link rel="stylesheet" id="caseicon-css" href="css/caseicon.min.css" type="text/css" media="all">
		<link rel="stylesheet" id="flaticon2-css" href="css/flaticon2.min.css" type="text/css" media="all">
		<link rel="stylesheet" id="industo-theme-css" href="css/industo-theme.min.css" type="text/css" media="all">
		<link rel="stylesheet" id="elementor-frontend-css" href="css/frontend-lite.min.css" type="text/css" media="all">
		<link rel="stylesheet" id="elementor-post-6-css" href="css/post-6.css" type="text/css" media="all">
		<link rel="icon" type="image/png" href="images/favi.png">
		<link rel="stylesheet" id="elementor-post-146-css" href="css/post-146.css" type="text/css" media="all">
		<link rel="stylesheet" id="elementor-post-2951-css" href="css/post-2951.css" type="text/css" media="all">
		<link rel="stylesheet" id="elementor-post-13732-css" href="css/post-13732.css" type="text/css" media="all">
		<style id="ct_theme_options-dynamic-css" title="dynamic-css" class="redux-options-output">body #ct-pagetitle{background-image:url('./images/pageimages/contact.jpg');}a{color:#fa0000;}a:hover{color:#fa0000;}a:active{color:#fa0000;}</style>
		<style id="ct-page-dynamic-css" data-type="redux-output-css">#content{padding-top:0px;padding-bottom:0px;}</style>
		
	</head>
	<body class="home page-template-default page page-id-86 theme-industo woocommerce-js redux-page  site-h146 body-default-font heading-default-font  site-404-default elementor-default elementor-kit-7 elementor-page elementor-page-86">
		<div id="page" class="site">
			<!-- <div id="ct-loadding" class="ct-loader style14">
				<div class="ct-gears">
					<img class="big" src="images/favi.png" alt="Industry">
				</div>
			</div> -->
			<div class="ct-page-loading-bg active"></div>
			<?php require('inc/header.php'); ?>



            <div id="ct-pagetitle" class="ct-pagetitle bg-image text-left">
                <div class="container style="opacity: 1;>
                    <ul class="ct-breadcrumb">
                        <li><a class="breadcrumb-entry" href="./index.html">Home</a></li>
                        <li><span class="breadcrumb-entry">Contact</span></li>
                    </ul>
                    <div class="ct-page-title-holder">
                        <h1 class="ct-page-title">Contact Us</h1></div>
                </div>
            </div>


            <div id="content" class="site-content">
				<div class="content-inner">
					<div class="container content-container">
						<div class="row content-row">
							<div id="primary" class="content-area content-full-width col-12">
								<main id="main" class="site-main">
									<article id="post-527" class="post-527 page type-page status-publish hentry">
										<div class="entry-content clearfix">
											<div data-elementor-type="wp-page" data-elementor-id="527" class="elementor elementor-527">
												<section
													class="elementor-section elementor-top-section elementor-element elementor-element-89c9812 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default ct-header-fixed-none ct-column-none ct-row-scroll-none ct-row-gradient--none ct-row-container--default"
													data-id="89c9812"
													data-element_type="section"
													data-settings='{"stretch_section":"section-stretched"}'
													style="width: 1519px; left: -174.6px;"
												>
													<div class="elementor-container elementor-column-gap-extended">
														<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2ba1be0 ct-column-none col-offset-none" data-id="2ba1be0" data-element_type="column">
															<div class="elementor-widget-wrap elementor-element-populated">
																<div class="elementor-element elementor-element-6caf3df elementor-widget elementor-widget-ct_heading" data-id="6caf3df" data-element_type="widget" data-widget_type="ct_heading.default">
																	<div class="elementor-widget-container">
																		<div id="ct_heading-6caf3df" class="ct-heading h-align-center item-st-default">
																			<div class="heading-wrapper">
																				<div class="inner-heading">
																					<h3 class="item--title case-animate-time st-default" data-wow-delay="ms"><span>Feel free to contact with<br />
																						us any time.</span></h3>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
																<section
																	class="elementor-section elementor-inner-section elementor-element elementor-element-6aab44c elementor-section-boxed elementor-section-height-default elementor-section-height-default ct-header-fixed-none ct-column-none ct-row-scroll-none ct-row-gradient--none ct-row-container--default"
																	data-id="6aab44c"
																	data-element_type="section"
																>
																	<div class="elementor-container elementor-column-gap-extended">
																		<div
																			class="elementor-column elementor-col elementor-inner-column elementor-element elementor-element-942afde ct-column-none col-offset-none"
																			data-id="942afde"
																			data-element_type="column"
																		>
																			<div class="elementor-widget-wrap elementor-element-populated">
																				<div
																					class="elementor-element elementor-element-7e1d60e elementor-widget elementor-widget-ct_info_box"
																					data-id="7e1d60e"
																					data-element_type="widget"
																					data-widget_type="ct_info_box.default"
																				>
																					<div class="elementor-widget-container">
																						<div id="ct_info_box-7e1d60e" class="ct-info-box layout1 wow fadeInUp" data-wow-delay="ms" style="visibility: visible; animation-name: fadeInUp;">
																							<div class="inner-box">
																								<div class="meta-box">
																									<div class="item--icon icon-right-from-Left"><i aria-hidden="true" class="flaticon flaticon-message"></i></div>
																									<div class="item--meta">
																										<h3 class="item--title">Head Office</h3>
																										<div class="sub-title">Kamhan Industrial Limited <br>香港锦亨实业有限公司 (温州代表处）</div>
																									</div>
																								</div>
																								<ul class="list-row">
																									<li class="item--contact-info">
																										<p>ROOM 1012-13, BEVERLEY COMMERCIAL CENTRE</p>
																										<p>NO.87-105 CHATHAM ROAD, TSIM SHA TSUI,</p>
																										<p>KOWLOON HONGKONG</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-mobile-screen px-20"></i>
																											+852 93665561 (WECHAT & WHATSAPP)
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-tty px-20"></i>
																											+852-23681383
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-fax px-20"></i>
																											+852-23682968
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<i class="fa-solid fa-envelope px-20"></i>
																										<a href="mailto:kamhan@kamhan.com"> <span class="ct-contact-content"> kamhan@kamhan.com </span> </a>
																									</li>
																								</ul>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																			
																		</div>


																		<div
																			class="elementor-column elementor-col elementor-inner-column elementor-element elementor-element-942afde ct-column-none col-offset-none"
																			data-id="942afde"
																			data-element_type="column"
																		>
																			<div class="elementor-widget-wrap elementor-element-populated">
																				<div
																					class="elementor-element elementor-element-7e1d60e elementor-widget elementor-widget-ct_info_box"
																					data-id="7e1d60e"
																					data-element_type="widget"
																					data-widget_type="ct_info_box.default"
																				>
																					<div class="elementor-widget-container">
																						<div id="ct_info_box-7e1d60e" class="ct-info-box layout1 wow fadeInUp" data-wow-delay="ms" style="visibility: visible; animation-name: fadeInUp;">
																							<div class="inner-box">
																								<div class="meta-box">
																									<div class="item--icon icon-right-from-Left"><i aria-hidden="true" class="flaticon flaticon-message"></i></div>
																									<div class="item--meta">
																										<h3 class="item--title">Guangzhou Office</h3>
																										<div class="sub-title">Kamhan Industrial Limited</div>
																									</div>
																								</div>
																								<ul class="list-row">
																									<li class="item--contact-info">
																										<p>RM14E,Baili Commercial Center</p>
																										<p>No.498,Huanshidong
																											Road</p>
																										<p>Yuexiu District,Guangzhou,China</p>
																										<p>广州市越秀区环市东路498号柏丽商业中心14E</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-tty px-20"></i>
																											020-83586505/83509232
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-fax px-20"></i>
																											020-83488524
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<i class="fa-solid fa-envelope px-20"></i>
																										<a href="mailto:guangzhou_off1@kamhan.net"> <span class="ct-contact-content"> guangzhou_off1@kamhan.net </span> </a>
																										<a href="mailto:guangzhou_off2@kamhan.net"> <span class="ct-contact-content"> guangzhou_off2@kamhan.net </span> </a>
																									</li>
																								</ul>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																			
																		</div>

																		

																	</div>




																	<div class="elementor-container elementor-column-gap-extended">
																		

																		<div
																			class="elementor-column elementor-col elementor-inner-column elementor-element elementor-element-942afde ct-column-none col-offset-none"
																			data-id="942afde"
																			data-element_type="column"
																		>
																			<div class="elementor-widget-wrap elementor-element-populated">
																				<div
																					class="elementor-element elementor-element-7e1d60e elementor-widget elementor-widget-ct_info_box"
																					data-id="7e1d60e"
																					data-element_type="widget"
																					data-widget_type="ct_info_box.default"
																				>
																					<div class="elementor-widget-container">
																						<div id="ct_info_box-7e1d60e" class="ct-info-box layout1 wow fadeInUp" data-wow-delay="ms" style="visibility: visible; animation-name: fadeInUp;">
																							<div class="inner-box">
																								<div class="meta-box">
																									<div class="item--icon icon-right-from-Left"><i aria-hidden="true" class="flaticon flaticon-message"></i></div>
																									<div class="item--meta">
																										<h3 class="item--title">Delhi Office</h3>
																										<div class="sub-title">M/s DPR Moulds & Machineries PVT LTD</div>
																									</div>
																								</div>
																								<ul class="list-row">
																									<li class="item--contact-info">
																										<p>37, Nagin Lake Apartments</p>
																										<p>Near Peera Garhi Chowk</p>
																										<p>Paschim Vihar, New Delhi-110087</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-mobile-screen px-20"></i>
																											011-25285363
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<i class="fa-solid fa-envelope px-20"></i>
																										<a href="mailto:dprmachineries@gmail.com"> <span class="ct-contact-content"> dprmachineries@gmail.com </span> </a>
																									</li>
																								</ul>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																			
																		</div>


																		<div
																			class="elementor-column elementor-col elementor-inner-column elementor-element elementor-element-942afde ct-column-none col-offset-none"
																			data-id="942afde"
																			data-element_type="column"
																		>
																			<div class="elementor-widget-wrap elementor-element-populated">
																				<div
																					class="elementor-element elementor-element-7e1d60e elementor-widget elementor-widget-ct_info_box"
																					data-id="7e1d60e"
																					data-element_type="widget"
																					data-widget_type="ct_info_box.default"
																				>
																					<div class="elementor-widget-container">
																						<div id="ct_info_box-7e1d60e" class="ct-info-box layout1 wow fadeInUp" data-wow-delay="ms" style="visibility: visible; animation-name: fadeInUp;">
																							<div class="inner-box">
																								<div class="meta-box">
																									<div class="item--icon icon-right-from-Left"><i aria-hidden="true" class="flaticon flaticon-message"></i></div>
																									<div class="item--meta">
																										<h3 class="item--title">Jinjiang Office</h3>
																										<div class="sub-title">Kamhan Industrial Limited <br>香港锦亨实业有限公司</div>
																									</div>
																								</div>
																								<ul class="list-row">
																									<li class="item--contact-info">
																										
																										<p>ROOM 603,BUILDING 6,BAOLONG GARDEN</p>
																										<p>JINJIANG,FUJIANG,CHINA</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-mobile-screen px-20"></i>
																											18659503536
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-tty px-20"></i>
																											0595-85605820
																										</p>
																									</li>
																								</ul>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																			
																		</div>
																		
																	</div>



																	<div class="elementor-container elementor-column-gap-extended">
																		
																		<div
																			class="elementor-column elementor-col elementor-inner-column elementor-element elementor-element-942afde ct-column-none col-offset-none"
																			data-id="942afde"
																			data-element_type="column"
																		>
																			<div class="elementor-widget-wrap elementor-element-populated">
																				<div
																					class="elementor-element elementor-element-7e1d60e elementor-widget elementor-widget-ct_info_box"
																					data-id="7e1d60e"
																					data-element_type="widget"
																					data-widget_type="ct_info_box.default"
																				>
																					<div class="elementor-widget-container">
																						<div id="ct_info_box-7e1d60e" class="ct-info-box layout1 wow fadeInUp" data-wow-delay="ms" style="visibility: visible; animation-name: fadeInUp;">
																							<div class="inner-box">
																								<div class="meta-box">
																									<div class="item--icon icon-right-from-Left"><i aria-hidden="true" class="flaticon flaticon-message"></i></div>
																									<div class="item--meta">
																										<h3 class="item--title">Wenzhou Office</h3>
																										<div class="sub-title">Kamhan Industrial Limited<br>香港锦亨实业有限公司 (温州代表处）</div>
																									</div>
																								</div>
																								<ul class="list-row">
																									<li class="item--contact-info">
																										
																										<p>UNIT 3B-702, THE 3RD SECTION OF NATURAL COURTYARD. </p>
																										<p>TANGJIAQIAO RD (S )
																											WENZHOU CITY-325011</p>
																										<p>ZHEJIANG PROVINCE. CHINA</p>
																										<p>浙江省温州市鹿城区汤家桥南路大自然家园3期3B-702室</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-mobile-screen px-20"></i>
																											+8613588930376 CHHAJER AND +852 64071151<br>
																											+8613588930325 SUMMER<br>
																											+8613858864070 SWACHIT AND +852 64071147
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-tty px-20"></i>
																											0086-577-89889925
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<p><i class="fa-solid fa-fax px-20"></i>
																											0086-577-89889926/24
																										</p>
																									</li>
																									<li class="item--contact-info">
																										<i class="fa-solid fa-envelope px-20"></i>
																										<a href="mailto:wenzhou_off1@kamhan.net"> <span class="ct-contact-content"> wenzhou_off1@kamhan.net </span> </a>
																									</li>
																								</ul>
																							</div>
																						</div>
																					</div>
																				</div>
																			</div>
																			
																		</div>
																	</div>
																	
																</section>
															</div>
														</div>
													</div>
												</section>
												<section
													class="elementor-section elementor-top-section elementor-element elementor-element-ae56fd5 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default ct-header-fixed-none ct-column-none ct-row-scroll-none ct-row-gradient--none ct-row-container--default"
													data-id="ae56fd5"
													data-element_type="section"
													data-settings='{"stretch_section":"section-stretched"}'
													style="width: 1519px; left: -174.6px;"
												>
													<div class="elementor-container elementor-column-gap-extended">
														<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5dc2490 ct-column-none col-offset-none" data-id="5dc2490" data-element_type="column">
															<div class="elementor-widget-wrap elementor-element-populated">
																<div class="elementor-element elementor-element-f86b8b3 elementor-widget elementor-widget-ct_heading" data-id="f86b8b3" data-element_type="widget" data-widget_type="ct_heading.default">
																	<div class="elementor-widget-container">
																		<div id="ct_heading-f86b8b3" class="ct-heading h-align-center item-st-default">
																			<div class="heading-wrapper">
																				<div class="inner-heading">
																					<div class="item--sub-title no-image-bg"><span> </span></div>
																					<h3 class="item--title case-animate-time st-default" data-wow-delay="ms">
																						<span>
																							Get In Touch 
																						</span>
																					</h3>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
																<div
																	class="elementor-element elementor-element-63a5d28 elementor-widget elementor-widget-ct_contact_form"
																	data-id="63a5d28"
																	data-element_type="widget"
																	data-widget_type="ct_contact_form.default"
																>
																	<div class="elementor-widget-container">
																		<div class="ct-contact-form ct-contact-form-layout1 style1">
																			<div class="inner-layout">
																				<div class="ct-contact-form">
																					<div class="wpcf7 js" id="wpcf7-f713-p527-o1" lang="en-US" dir="ltr">
																						<div class="screen-reader-response">
																							<p role="status" aria-live="polite" aria-atomic="true"></p>
																							<ul></ul>
																						</div>
																						<form action="/industo/contact-us/#wpcf7-f713-p527-o1" method="post" class="wpcf7-form init" aria-label="Contact form" novalidate="novalidate" data-status="init">
																							<div style="display: none;">
																								<input type="hidden" name="_wpcf7" value="713" /> <input type="hidden" name="_wpcf7_version" value="5.7.6" />
																								<input type="hidden" name="_wpcf7_locale" value="en_US" /> <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f713-p527-o1" />
																								<input type="hidden" name="_wpcf7_container_post" value="527" /> <input type="hidden" name="_wpcf7_posted_data_hash" value="" />
																							</div>
																							<div class="wp-row-ctf7">
																								<div class="row">
																									<div class="col-lg-6 col-md-6">
																										<div class="input-filled">
																											<p>
																												<span class="wpcf7-form-control-wrap" data-name="your-name">
																													<input
																														size="40"
																														class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
																														aria-required="true"
																														aria-invalid="false"
																														placeholder="Your Name"
																														value=""
																														type="text"
																														name="your-name"
																													/>
																												</span>
																											</p>
																										</div>
																									</div>
																									<div class="col-lg-6 col-md-6">
																										<div class="input-filled">
																											<p>
																												<span class="wpcf7-form-control-wrap" data-name="your-email">
																													<input
																														size="40"
																														class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email"
																														aria-required="true"
																														aria-invalid="false"
																														placeholder="Your Email"
																														value=""
																														type="email"
																														name="your-email"
																													/>
																												</span>
																											</p>
																										</div>
																									</div>
																									<div class="col-lg-6 col-md-6">
																										<div class="input-filled">
																											<p>
																												<span class="wpcf7-form-control-wrap" data-name="your-phone">
																													<input
																														size="40"
																														class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
																														aria-required="true"
																														aria-invalid="false"
																														placeholder="Your Phone"
																														value=""
																														type="text"
																														name="your-phone"
																													/>
																												</span>
																											</p>
																										</div>
																									</div>
																									<div class="col-lg-6 col-md-6">
																										<div class="input-filled">
																											<p>
																												<span class="wpcf7-form-control-wrap" data-name="your-subject">
																													<input
																														size="40"
																														class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
																														aria-required="true"
																														aria-invalid="false"
																														placeholder="Your Subject"
																														value=""
																														type="text"
																														name="your-subject"
																													/>
																												</span>
																											</p>
																										</div>
																									</div>
																									<div class="col-lg-12">
																										<div class="input-filled">
																											<p>
																												<span class="wpcf7-form-control-wrap" data-name="your-message">
																													<textarea
																														cols="40"
																														rows="10"
																														class="wpcf7-form-control wpcf7-textarea"
																														aria-invalid="false"
																														placeholder="Message"
																														name="your-message"
																													></textarea>
																												</span>
																											</p>
																										</div>
																									</div>
																									<div class="col-lg-12">
																										<div class="input-filled input-filled-btn">
																											<p><input class="wpcf7-form-control has-spinner wpcf7-submit" type="submit" value="Send Message +" /><span class="wpcf7-spinner"></span></p>
																										</div>
																									</div>
																								</div>
																							</div>
																						</form>
																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</section>
											</div>
										</div>
										<!-- .entry-content -->
									</article>
									<!-- #post-527 -->
								</main>
								<!-- #main -->
							</div>
							<!-- #primary -->
						</div>
					</div>
				</div>
				<!-- #content inner -->
			</div>
			
			<!-- #content -->
			<?php require('inc/footer.php'); ?>
			<a href="#" class="scroll-top">
				<span>
					<i class="caseicon-long-arrow-right-three"></i>
				</span>
			</a>
		</div>
		<!-- #page -->
		




		<script src="js/wp-emoji-release.min.js" defer=""></script>
		<script type="text/javascript" src="js/jquery.min.js" id="jquery-core-js"></script>
		<script type="text/javascript" src="js/jquery.min.js" id="jquery-core-js"></script>
		<script type="text/javascript" src="js/industo-main.min.js" id="industo-main-js"></script>
		<script type="text/javascript" src="js/ct-inline-css.js" id="ct-inline-css-js-js"></script>
		<script type="text/javascript" src="js/webpack.runtime.min.js" id="elementor-webpack-runtime-js"></script>
		<script type="text/javascript" src="js/frontend-modules.min.js" id="elementor-frontend-modules-js"></script>
		<script id="elementor-frontend-js-before" type="text/javascript"> var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.12.2","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"additional_custom_breakpoints":true,"landing-pages":true},"urls":{"assets":"https:\/\/demo.casethemes.net\/industo\/wp-content\/plugins\/elementor\/assets\/"},"swiperClass":"swiper-container","settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":6,"title":"Industo%20%E2%80%93%20Industry%20%26%20Factory%20WordPress","excerpt":"","featuredImage":false}}; 
		</script>
		<script type="text/javascript" src="js/frontend.min.js" id="elementor-frontend-js"></script>
	</body>
</html>