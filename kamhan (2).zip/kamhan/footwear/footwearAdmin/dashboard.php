<?php require_once 'header.php'; ?>
   <h3>Hello Administrator!</h3>
   <p>You signed in as Administrator.<br> Now you can manage your website`s content here by selecting the related tabs in left m</p>
  <?php require_once 'footer.php'; ?>